const recipes = [
    { id: 1, name: 'Spaghetti Bolognese', ingredients: ['spaghetti', 'ground beef', 'tomato sauce'], isFavourite: true },
    { id: 2, name: 'Chicken Curry', ingredients: ['chicken', 'curry powder', 'coconut milk'], isFavourite: false },
    { id: 3, name: 'Vegetable Stir Fry', ingredients: ['mixed vegetables', 'soy sauce', 'ginger'], isFavourite: false },
];
module.exports = recipes;